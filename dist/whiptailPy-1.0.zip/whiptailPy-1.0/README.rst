whiptail
==================================================

Use whiptail to display dialog boxes from shell scripts.

Installation
------------

  $ pip install whiptailPy

Links
-----

* `Fork me on GitHub <https://github.com/fillips/whiptail>`_

